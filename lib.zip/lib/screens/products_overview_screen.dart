// import 'dart:html';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shop_app/providers/product.dart';
import 'package:shop_app/providers/cart.dart';
import 'package:shop_app/providers/products.dart';
import 'package:shop_app/screens/cart_screen.dart';
import 'package:shop_app/widgets/badge.dart';
import 'package:shop_app/widgets/main_drawer.dart';
import 'package:shop_app/widgets/product_grid.dart';
import 'package:shop_app/widgets/product_item.dart';

enum FilterOptions { Favorites, All }

class ProductOverviewScreen extends StatefulWidget {
  static const routeName='/product-overview';
  @override
  State<ProductOverviewScreen> createState() => _ProductOverviewScreenState();
}

class _ProductOverviewScreenState extends State<ProductOverviewScreen> {
  var showOnlyFavorites = false;
  var _isInit=true;
  var _isLoading=false;
  @override
  void initState() {
    // TODO: implement initState
    
    

    
    super.initState();
  }
  @override
  void didChangeDependencies() {

    // TODO: implement didChangeDependencies

    if(_isInit)
    { setState(() {
      _isLoading=true;
    }); 
      Provider.of<Products>(context).fetchAndSetProducts().then((value) {
        setState(() {
          _isLoading=false;
        });
        } );
    }
    _isInit=false;
    super.didChangeDependencies();

  }

  @override
  Widget build(BuildContext context) {
     final cart = Provider.of<Cart>(context);
    final productsContainer = Provider.of<Products>(context, listen: false);
    return Scaffold(
        appBar: AppBar(
          title: Text("MyShop"),
          actions: [
            PopupMenuButton(
                onSelected: (FilterOptions selectedValue) {
                  setState(() {
                    if (selectedValue == FilterOptions.Favorites) {
                      showOnlyFavorites = true;
                    } else {
                      showOnlyFavorites = false;
                    }
                  });
                },
                itemBuilder: (ctx) => [
                      PopupMenuItem(
                        child: Text("Only Favorites"),
                        value: FilterOptions.Favorites,
                      ),
                      PopupMenuItem(
                        child: Text("Show all"),
                        value: FilterOptions.All,
                      ),
                    ],
                icon: Icon(Icons.more_vert)),
            Consumer<Cart>(
                builder: (context, cartData, ch) => Flexible(
                  child: Badge(child: ch,
                      
                      value: cartData.itemCount.toString()),
                ),
                    
                    child: IconButton(
                        onPressed: () {
                          Navigator.of(context).pushNamed(CartScreen.routeName);




                        }, icon: Icon(Icons.shopping_cart)),
                    
                    )
          ],
        ),
        drawer:  MainDrawer(),
        body:_isLoading?Center(child:CircularProgressIndicator()): ProductGrid(showOnlyFavorites));
  }
}
